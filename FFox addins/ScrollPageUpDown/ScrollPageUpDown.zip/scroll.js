window.addEventListener("keydown", function (event) {

	if (event.defaultPrevented) {
    return; // Do nothing if the event was already processed
  }
   // if (event.getModifierState("Shift") && event.key === "z") {
  switch (event.key) {
	  

	
	case "F1":
		if (event.getModifierState("Control") )
			window.scrollByPages(-99);
		else
			window.scrollByPages(-1);
		break;
		
	case "F2": 
		if (event.getModifierState("Control") )
			window.scrollByPages(99);
		else
			window.scrollByPages(1);
		break;
		
	default:
		return; // Quit when NOT handling the event.
  }

  // Cancel the default action to avoid it being handled twice
  event.preventDefault();
}, true);


